﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dec.Bin._2021
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero mi pana");
            int numero = Convert.ToInt32(Console.ReadLine());
            if (numero > 0)
            {
                String cadena = "";
                while (numero > 0)
                {
                    if (numero % 2 == 0)
                    {
                        cadena = "0" + cadena;
                    }
                    else
                    {
                        cadena = "1" + cadena;
                    }
                    numero = (int)(numero / 2);
                }
                Console.WriteLine(cadena);
            }
            else
            {
                if (numero == 0)
                {
                    Console.WriteLine("0");
                }

            }
            Console.ReadLine();

        }
    }
}